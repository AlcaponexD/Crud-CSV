<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 29/04/2018
 * Time: 10:43
 */
require_once ('conexao.php');

$stmt = $connect->prepare("INSERT INTO td_usuario (deslogin, dessenha) VALUES (?, ?)");
$stmt->bind_param("ss" , $login , $senha);
$login = "AlcaponexD";
$senha = "1234235";

$stmt->execute();