<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
* Date: 29/04/2018
* Time: 10:39
*/
//Chama a classe mysqli e conecta no localhost usuario root , senha em branco , banco dbphp7
$connect =new mysqli("localhost", "root", "" ,"dbphp7");
    //Se der error executa o seguinte funcao:
    if ($connect->connect_error){
        //Mostra o error ocorrido.
        echo "Error" .$connect->connect_error;
    }