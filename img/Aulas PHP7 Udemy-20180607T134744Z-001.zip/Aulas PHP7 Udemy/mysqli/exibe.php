<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 29/04/2018
* Time: 11:15
*/
//Feita conecao no db com arquivo externo
require_once ("conexao.php");
//Resgata uma consulta ao banco de dados apartir da propriedade do connect
$resgatar = $connect->query("select * from td_usuario Order By deslogin");
//Variavel com array que vai receber os dados
$data = array();
//Laço de repetiçao , só acaba quando o valor na db acavar ( cria variavel $row que irá ser igual a variavel $resgatar que está com a consulta depois acessa propriedade e puxa os dados
//e o array push serve para adicionar dados em alguma variavel , no caso ele vai adicionar os dados na $data  e puxar os dados da row para isso
while ($row = $resgatar->fetch_assoc()){
    array_push($data, $row);


}
//Exibe um json
echo json_encode($data);