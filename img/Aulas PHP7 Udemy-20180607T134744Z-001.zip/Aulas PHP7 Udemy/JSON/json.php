<?php

$pessoas = array();
array_push($pessoas , array(
    'Nome' => 'Jeison',
    'Idade' => '26'

));

array_push($pessoas , array(
    'Nome' => 'TESTE',
    'Idade' => '22'
));
//json_encode serve para gerar um json apartir de um array
echo json_encode($pessoas);
?>