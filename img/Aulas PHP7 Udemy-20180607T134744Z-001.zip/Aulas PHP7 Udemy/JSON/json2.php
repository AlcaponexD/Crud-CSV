<?php
$json = '[{"Nome":"Jeison","Idade":"26"},{"Nome":"TESTE","Idade":"22"}]';

$data = json_decode($json,true);

var_dump($data); 
?>