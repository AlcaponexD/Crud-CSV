<?php
$semana = ['Segunda' , 'Terça', 'Quarta', 'Quinta' , 'Sexta' , 'Sabado', 'Domingo'];

foreach ($semana as $dias) {
    echo "O dia da semana é $dias\n",  "<br>";

}

?>  