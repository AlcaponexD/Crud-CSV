<?php
//For é repetição. / / ($i=0 cria variavel com valor 0 , $i < 10 variavel vai até o maximo 10 ; $i++  a variavel i vai receber incremento de +1)
for ($i=0; $i < 10 ; $i++) { 
    echo $i;
}


//Select dinamico com ano
echo "<select>";    
//For pegou a data Y (ano) ele vai executar até -100 anos ou seja , vai executar de 1918 até 2018 data atual e como é denumero baixo pra alto , usa decremento --
for ($i= date("Y"); $i > date("Y")-100; $i--){
    echo '<option value= "'.$i.'">'.$i.'</option>' ;
}
echo "</select>";


?>
