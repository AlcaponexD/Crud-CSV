<?php
//Variavel de data para pegar o ID (numero do dia)
$data = date("w");
//Switch serve para executar uma terefa se o valor for EXATAMENTE oque ele espera nos case.
switch ($data) {
    //Case serve para dar a condição , no caso 0 é o dia
    case 0:
    //Caso for essa condição exibe domingo
        echo "Domingo";
    //Se a condição for aceita ele executa tudo e para a execução de codigo no coman do break.
        break;

    case 1:
        echo "Segunda";
        break;

    case 2:
        echo "Terça";
        break;

    case 3:
        echo "Quarta";
        break;

    case 4:
        echo "Quinta";
        break;
    
    case 5:
        echo "Sexta";
        break;

    case 6:
        echo "Sabado";
    }


?>