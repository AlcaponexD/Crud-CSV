<?php
$salario = 45454;

$salarioLixo = 800; //"Seu salario é uma porcaria";
$salarioNormal = 1400; //"Salario meia boca";
$salarioAcima = 2500; //"Ta Melhorando";
$salarioNervoso = 5000; //"To sonhando véi";
//Condição se 
if ($salario <= $salarioLixo){
    echo "Seu salario é uma porcaria";
//Condição senão for aquilo , tenta  isso
} elseif($salario <= $salarioNormal){
    echo "Salario meia boca";
//Condição senão for aquilo , tenta isso
} elseif($salario <= $salarioAcima){
    echo "Ta melhorando";
//Se nenhuma condição acima for aceita , ele executa o codigo abaixo.
} else{
    echo "To sonhando véi";
}


?>