<form>
  <fieldset>
    <legend>Personal information:</legend>
    First name:<br>
    <input type="text" name="firstname"><br>
    Last name:<br>
    <input type="text" name="lastname"<br><br>
    <input type="date" name="nascimento"><br>
    <input type="submit" value="Submit">
  </fieldset>
</form>

<?php
//Isset serve para verificar a existencia da variavel , evitando erros caso nao exista
if (isset($_GET)){
    //Ele pega a variavel $_GET que ela por si pega os dados do formulario de modo padrao e joga cada campo na variavel $key  e joga o valor digitado para $value
    foreach ($_GET as $key => $value) {
        echo "Nome do campo no codigo: " .$key ."<br>";
        echo "Valor digitado do campo: " .$value;
        echo "<hr>";
    }
}
?>