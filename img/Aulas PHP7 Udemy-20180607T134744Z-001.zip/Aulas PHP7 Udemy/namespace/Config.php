<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
* Date: 28/04/2018
* Time: 00:56
*/
//Chama as classes que tem o mesmo nome no arquivo.php dda pasta class
spl_autoload_register(function ($nameClass){
    //Variavel para passar o nome da pasta
    $dir = "class";
    //Variavel para puxar o caminho completo da pasta com extenção .php
    $filename = $dir . DIRECTORY_SEPARATOR . $nameClass . ".php";
    //Se caso o arquivo existir ou seja $filename
    if (file_exists($filename)){
        //Ele carrega o arquivo que foi gerado no filename no caso , alguma class.php (EX : Cadastro.php
        require_once ($filename);
    }
});