<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 28/04/2018
 * Time: 01:08
 */
//Use serve para puxar a classe dentro de um namespace
use Cliente\Cadastro;
//Puxa o arquivo de configuração , que puxa as classes
require_once ("config.php");

$cad = new Cadastro();
$cad->setNome("Jeison Pedroso");
$cad->setEmail("AlcaponexD@msn.com");
$cad->setSenha("123456");
$cad->inc();

echo $cad;