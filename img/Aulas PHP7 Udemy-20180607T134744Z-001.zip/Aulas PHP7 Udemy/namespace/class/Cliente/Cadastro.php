<?php

/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 28/04/2018
 * Time: 01:22
 */

//namespace usado para criar algo especifico ou seja , no caso eu tenho um cadastro generico e puxo um namespace para colocar um cadastro especifico , porem com as mesma propriedade
namespace Cliente;
//Classe cadastro que extende de \cadastro , ou seja , pega a classe generica da pasta raiz
class Cadastro extends \Cadastro
{
    public function inc(){
        echo "Foi realizado uma venda para : ".$this->getNome();
    }
}