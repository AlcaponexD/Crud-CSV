<?php
//Escopo PHP
$nome = 'Jeison';

function teste(){
	global $nome;
	echo $nome;
}

teste();
//Para simplificar cada escopo é o corpo das funções e mesmo puxando variavel com nome identico , ela só funciona se estiver dentro do escopo, a função com o nome identico de fora ele ignora e por isso retorna erro caso nao existir a função dentro do escopo ()
function teste2(){

	$nome = 'Jeison';
	echo $nome;
}

teste2();

?>
