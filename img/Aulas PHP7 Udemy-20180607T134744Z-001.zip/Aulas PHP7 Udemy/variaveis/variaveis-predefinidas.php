<?php 
//Variavel get , recupera informações principalmente de formularios atravéz da url ( index.php?variavel=valor) se quiser pegar duas variaveis via get é ?variavel=valor&variavel=valor
$nome = (int)$_GET["a"];

//var_dump($nome);

//Variavel para pegar ip
$ip = $_SERVER['REMOTE_ADDR'];
	echo($ip);

//serve para retornar 
$srname = $_SERVER['SCRIPT_NAME'];
	echo($srname);	

 ?>