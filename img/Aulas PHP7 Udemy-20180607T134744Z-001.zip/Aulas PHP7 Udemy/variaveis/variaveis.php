<?php
//Variavel tipo string ( ou seja palavras / frases , sempre fechar com aspas igual )
$nome = "jeison";

$sobrenome = "pedroso";

$nomeCompleto = $nome .' '. $sobrenome; //Para concatenar é usado o "   .   " ( ponto)   / / .' '. serve para concatenar com espaço para nao colar as palavras

//variavel tipo inteira
$nascimento = 1990;

//variavel tipo float
$dinheiro  = 10.52;

//variavel tipo boolean
$verdade = true; // ou poderia ser = false;

//Variavel do tipo array
$frutas = array('abacaxi' , 'morango ' , 'uva' , 'limao');

//Variavel tipo data
$nascimento  = new DateTime();

//Variavel para arquivos 
$arquivo = fopen('index.php', 'r');

//mostra a quantidade de bites que são consumidos na memoria
var_dump($nome);

echo $dinheiro;

echo "<br/>"; //Serve para exibir ou mostrar algum dado

//unset(nascimento); //Serve para limpar a variavel após ela ter sido ocupada.

if (isset($dinheiro)) {
	// caso a variavel dinheiro existir o comendo entre a chaves passa a ser executado;
	echo $dinheiro;
}

echo "<br/>";

if (isset($nomeCompleto)) {
	//Se a variavel nomeCompleto existir é executado o comando abaixo
	echo $nomeCompleto;
}

?>
