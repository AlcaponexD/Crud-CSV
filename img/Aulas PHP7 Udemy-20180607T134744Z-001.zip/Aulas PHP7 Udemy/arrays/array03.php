<?php

$pessoas = array();
array_push($pessoas , array(
    'Nome' => 'Jeison',
    'Idade' => '26'

));

array_push($pessoas , array(
    'Nome' => 'TESTE',
    'Idade' => '22'
));

print_r ($pessoas);
?>