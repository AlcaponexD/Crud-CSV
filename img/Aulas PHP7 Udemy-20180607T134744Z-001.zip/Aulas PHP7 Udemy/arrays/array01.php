<?php
//Cria um array (na verdade vetor , pois só tem uma dimensão)
$frutas = array('banana', 'maça', 'uva', 'morango');

print_r ($frutas);

?>