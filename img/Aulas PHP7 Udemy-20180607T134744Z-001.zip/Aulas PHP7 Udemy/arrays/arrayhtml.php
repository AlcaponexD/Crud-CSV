<?php 

$data = array(
	'titulo' => 'ZeroG',
	'site'	 => 'zerog.com.br',
	'conteudo' => array(
		array(
			'titulo2' => 'Titulo da noticia',
			'resumo'  => 'Resumo da noticia',
			'texto'   => 'Texto da noticia'
		),		
		array(
			'titulo2' => 'Titulo da noticia',
			'resumo'  => 'Resumo da noticia',
			'texto'   => 'Texto da noticia'
		),	
		array(
			'titulo2' => 'Titulo da noticia',
			'resumo'  => 'Resumo da noticia',
			'texto'   => 'Texto da noticia'
		)

		)
	);

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title> <?php $data['titulo']; ?> </title>
 </head>
 <body>
 	<h1><a href=" <?= $data['site'] ;?>"> <?= $data['titulo'] ;?></a></h1>
 		<?php 
 			foreach ($data['conteudo'] as $key => $value): ?>

 				<h2><?= $value['titulo2']; ?></h2>
 				<h3><?= $value['resumo']; ?></h3>
 				<p><?= $value['texto']; ?></p>

 			<?php endforeach; ?>


 </body>
 </html>