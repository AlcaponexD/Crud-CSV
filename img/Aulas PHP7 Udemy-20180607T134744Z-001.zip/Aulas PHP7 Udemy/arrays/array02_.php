<?php
//Grupo 0 gm    
$carros[0][0] = "GM";
$carros[0][1] = "Corsa";
$carros[0][2] = "Camaro";
//Grupo 01 VW
$carros[1][0] = "VW";
$carros[1][1] = "GOL";
$carros[1][2] = "FUSCA";
//Exibe o Grupo 0 na posição 2
echo $carros[0][2];
//END puxa o ultimo array do indice 1 (VW)
echo end($carros[1]);














?>