<?php 
//Operadores atribuição.
$nome = 'Jeison ';
echo $nome . 'Sobrenome' . '<br/>';


//Foi atribuido um novo valor na variavel nome , ele vai pegar o valor de cima e o novo valor em baixo	
$nome .= 'Pedroso' . '<BR/>';

echo $nome;

//Somar total  por exemplo de carrinho de compra

//Valor incial é 0
$valorTotal = 0 ;
//Foi somado mais 100 reais
$valorTotal += 100;
//foi somado mais 2131 reais
$valorTotal += 2131;
//Foi descontado 567 reais
$valorTotal -= 567;
//Foi descontado 15 % a vista
$valorTotal *= .9;

echo $valorTotal;

 ?>