<?php

$nome = $_GET ;
$sobrenome = 'Sobrenome bicha';

echo "Seu nome é ". " e seu " . $sobrenome;/////

print_r ($nome);
?>