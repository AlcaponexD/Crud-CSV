<?php 
$a = 23;

//Operadores de incremento e decremento
echo $a++;
echo "<br/>";
echo $a;
echo "<br/>";
echo $a--;
echo "<br/>";
echo $a;
echo "<br/>";
//Ou o incremento ou decremento pode vir antes da variavel para mosrar o resultado de imediato
echo ++$a;
echo "<br/>";
echo --$a;
echo "<br/>";

 ?>