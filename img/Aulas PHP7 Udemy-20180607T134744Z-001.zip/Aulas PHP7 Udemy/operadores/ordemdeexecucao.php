<?php  
/*
Ordem igual a matematica convencional

() ou [] ou {} ou ⊙⋆ ou ⋆√	
parênteses ◊ agrupamentos prévios
2)	⊙⋆ ou ⋆√	
potênciação ◊ radiciação
3)	⊙×⋆ ou ⊙÷⋆ ou ⊙⋆	
multiplicação ◊ divisão
4)	⊙+⋆ ou ⊙−⋆	
adição ◊ subtração
*/
$resultado = (213*2131) + 54 / 56;
echo $resultado;

//Exemplo de ordem de execução e comparação de duas condiçções  && serve para comparar duas condiçoes ou mais.
echo "<br/>";

$result = (10+5)/2 > 3 && 15 < 5;
//15/2 = 7.5 é maior que 3 (condição true)  , 15 não é menor que 5 então é false (Quando as duas condições são diferentes permanece a false.)
var_dump($result);

//Exemplo de ordem de execução e comparação de duas condiçções  || serve para comparar duas condiçoes se uma for verdadeira vai ser aceita ( true)
echo "<br/>";

$result = (10+5)/2 > 3 || 15 < 5;
//15/2 = 7.5 é maior que 3 (condição true)  , 15 não é menor que 5 então é false (porem || indica que se alguma for verdadeira vai prevalecer true apesar da outra condição nao ser true , ou seja uma das condições foi atendida.)
var_dump($result);
?>