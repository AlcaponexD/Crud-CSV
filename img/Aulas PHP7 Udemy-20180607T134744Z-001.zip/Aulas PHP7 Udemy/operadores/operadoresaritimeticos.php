<?php 
//Operadores basicos de matematica
//Valores
$a = 10;
$b = 2;
 
 //Soma
echo $a + $b;
echo "<br/>";
//subtração
echo $a - $b;
echo "<br/>";
//multiplicação 
echo $a * $b;
echo "<br/>";
//Divisão 
echo $a / $b;
echo "<br/>";
//Módulo  -- > Serve para mostrar o resto da divisão  , ex : 11/2 resultado é 5 e sobra 1;
echo $a % $b;
echo "<br/>";
//Potenciação
echo $a ** $b;
echo "<br/>";


 ?>