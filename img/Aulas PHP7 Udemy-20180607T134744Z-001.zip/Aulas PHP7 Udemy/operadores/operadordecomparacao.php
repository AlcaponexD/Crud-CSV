<?php 
//Operador de comparação.
//Variaveis numericas abaixo
$a = 23;
$b = 23.0;

//var_dump serve para mostrar o tipo da variavel e o valor

//A é maior que B?
var_dump($a > $b);
echo "<br/>";
//A é menor que B? 
var_dump($a < $b);
echo "<br/>";
// A é igual  a B? 
var_dump($a == $b);
// A é igual e também do mesmo tipo de  B? 
var_dump($a === $b);
echo "<br/>";
//A é maior ou igual a B?
var_dump($a >= $b);
echo "<br/>";
//A é menor ou igual a B?
var_dump($a <= $b);
echo "<br/>";
//A é diferente de B? 
var_dump($a != $b);
echo "<br/>";
//A é diferente  de B ? diferente o tipo de dado também ? 
var_dump($a !== $b);

//novos comparadores PHP7 Espaçonave ( se der 1  a é menor que b , se der 0 são iguals , se der -1 B é maior.)
var_dump($a <=> $b);
echo "<br/>";

//Operador novo que chama a primeura função , se for nula , chama a segunda , se for terceira , e assim vai 
$c = null;
$d = null;
$e = 22;

echo $c ?? $d ?? $e;
echo "<br/>";

 ?>