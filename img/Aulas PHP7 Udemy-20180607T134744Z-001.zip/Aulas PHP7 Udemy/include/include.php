<?php
//Include serve para incluir um arquivo PHP
/*Também existe
require = obriga que o arquivo exista e funcione bem
include = puxa o arquivo e mesmo que não exista executa o codigo.
require_once = obriga o arquivo exista e funcine bem e evita que
o mesmo seja puxado em duplicidade.
include_once = puxa o arquivo mesmo sem existir ele funciona e evita
de puxar o mesmo arquivo duas vezes
*/
include "inc/function.php";
//Após incluido a função foi chamado a mesma e passado 2 valores 

$resultado = somar (10 , 5);
echo $resultado;



?>