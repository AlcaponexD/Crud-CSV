<?php    
//Criado função de somar simples com dois valores a + b .
function somar($a , $b){
//para a função e retorna valor de A  +B
    return $a + $b;

}
?>