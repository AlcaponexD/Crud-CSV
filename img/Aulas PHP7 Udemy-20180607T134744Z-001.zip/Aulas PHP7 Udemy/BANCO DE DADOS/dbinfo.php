<?php
//Liga a db
USE dbphp7;
//Cria uma tabela no db selected
CREATE TABLE td_usuario(
    //cria id usuario do tipo inteiro nao vazio e com auto increment (joga sozinho o id)
idusuario INT NOT NULL PRIMARY KEY  AUTO_INCREMENT,
deslogin varchar(64) NOT NULL,
dessenha varchar(256) not null,
//Cria uma tabela indicando a hora que ele foi rgistrado
dtcadastro timestamp  not null default current_timestamp()
);
//Insere dados na tabela
insert into td_usuario (deslogin, dessenha) value('Jeison', '12345');
//Seleciona a tabela inteira e exibe dados
select * from td_usuario;

//Atualiza informaçoes
update td_usuario set dessenha = '123456' where idusuario = 1;
//Deleta dados de determinada tabela
delete from td_usuario where idusuario = 1;
//Reseta a tabela inteira (com isso os id volta do zero)
truncate table td_usuario;


//para usar , basta clicar na linha e dar ctrl+enter