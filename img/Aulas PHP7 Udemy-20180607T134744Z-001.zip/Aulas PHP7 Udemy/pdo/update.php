<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 01/05/2018
 * Time: 11:53
 */

$cnn = new PDO("mysql:host=localhost;dbname=dbphp7", "root", "");
//Altera dados  e é importante setar o ID
$smtm = $cnn->prepare("UPDATE td_usuario SET  deslogin = :login, dessenha = :senha where idusuario =:id");

$login = "Alterado";
$senha = "não é igual";
$id = 3;

$smtm->bindParam(":login", $login);
$smtm->bindParam(":senha", $senha);
$smtm->bindParam(":id", $id);

$smtm->execute();

echo "Alterado com sucesso";