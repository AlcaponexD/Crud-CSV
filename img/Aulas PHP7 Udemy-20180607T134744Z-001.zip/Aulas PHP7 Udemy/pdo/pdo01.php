<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 01/05/2018
 * Time: 09:45
 */
//Cria conexao com banco de dados
$cnn = new PDO("mysql:dbname=dbphp7;host=localhost" , "root", "");
//Executa uma consulta do banco de dados
$smtm = $cnn->prepare("SELECT * FROM  td_usuario ORDER BY deslogin");
//Executa a consulta acima e grava na variavel os dados
$smtm->execute();
//Cria uma nova variavel que irá receber o valor da variavel acima coomo um array de dados
$results = $smtm->fetchALL(PDO::FETCH_ASSOC);
    //Transforma os dados obtidos em linhas
    foreach ($results as $row) {
        //Transfere o valor da row para key e pega o value de key no caso o registro no banco
        foreach ($row as $key => $value)
        {
            //Exibe o nome da coluna do banco e concatena com o valor registrado no banco
            echo "<strong>".$key.":</strong>".$value."<Br>";
        }
        //Serve para colocar uma linha em cada execução do codigo , o codigo para de executar quando o array é retornado zero.
        echo "=======================================<br>";
    }

