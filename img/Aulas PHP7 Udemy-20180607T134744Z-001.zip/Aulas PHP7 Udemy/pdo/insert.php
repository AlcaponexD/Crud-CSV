<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 01/05/2018
 * Time: 11:02
 */
$cnn = new PDO("mysql:host=localhost;dbname=dbphp7", "root", "");

$smtm = $cnn->prepare("insert into td_usuario(deslogin, dessenha) VALUES (:login, :senha)");

$login = $_GET['deslogin'];
$senha = $_GET['dessenha'];

$smtm->bindParam(":login", $login);
$smtm->bindParam(":senha", $senha);

$smtm->execute();

echo "Inserido com sucesso";