<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 01/05/2018
 * Time: 11:53
 */

$cnn = new PDO("mysql:host=localhost;dbname=dbphp7", "root", "");
//Altera dados  e é importante setar o ID
$smtm = $cnn->prepare("DELETE FROM  td_usuario where idusuario =:id");


$id = 3;

$smtm->bindParam(":id", $id);

$smtm->execute();

echo "excluido com sucesso";