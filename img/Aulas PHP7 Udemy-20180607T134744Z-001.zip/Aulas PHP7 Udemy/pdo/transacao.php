<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 01/05/2018
 * Time: 11:53
 */

$cnn = new PDO("mysql:host=localhost;dbname=dbphp7", "root", "");

$cnn->beginTransaction();

//Altera dados  e é importante setar o ID
$smtm = $cnn->prepare("DELETE FROM  td_usuario where idusuario = ?");


$id = 1;


$smtm->execute(array($id));
//$cnn->rollback(); senão tive ok ele aborta toda a operaçao com roll back
//Caso esteja ok ,o commit manda executar
$cnn->commit();

echo "excluido com sucesso";