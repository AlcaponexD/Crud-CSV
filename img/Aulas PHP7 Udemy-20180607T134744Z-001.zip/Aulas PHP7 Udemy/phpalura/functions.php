<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 03/05/2018
 * Time: 22:21
 */

function listaProdutos($conexao){
    $produtos = array();
    $resultado = mysqli_query($conexao, "select * from produtos");
    while($produto = mysqli_fetch_assoc($resultado)) {
        array_push($produtos , $produto);

    }
    return $produtos;

}