<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 03/05/2018
 * Time: 21:27
 */
require_once ("header.php");
require_once ("db/conexao.php");
require_once ("functions.php");
?>
<table class="table table-striped table-bordered">

    <?php
        $produtos = listaProdutos($conexao);
        foreach($produtos as $produto) {
            ?>
            <tr>
                <td><?= $produto['produto_nome'] ?></td>
                <td><?= $produto['produto_valor'] ?></td>
            </tr>
            <?php
        }
    ?>
</table>
<?php
require_once ("footer.php");
