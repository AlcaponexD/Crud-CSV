<?php
require_once ("header.php");
require_once ("db/conexao.php");
?>

    <?php
    $produto_nome = $_GET["produto_nome"];
    $produto_valor = $_GET["produto_valor"];
    $query = "insert into produtos (produto_nome, produto_valor) values ('{$produto_nome}', '{$produto_valor}')";
    mysqli_query($conexao, $query);
    if(mysqli_query($conexao, $query)) {
        ?>
        <p class="alert-success">Produto <?= $produto_nome ?> no preco <?= $produto_valor ?> adicionado com sucesso!</p>
        <?php
    }else { ?>
        <p class="alert-success">Ocorreu um erro ao adicionar o produto</p>
    <?php }
    ?>


<?php require_once ("footer.php");?>