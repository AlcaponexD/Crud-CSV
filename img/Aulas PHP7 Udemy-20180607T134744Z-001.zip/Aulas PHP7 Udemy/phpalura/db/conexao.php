<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 02/05/2018
 * Time: 21:00
 */

$conexao = mysqli_connect("localhost", "root", "" , "dbphp7");