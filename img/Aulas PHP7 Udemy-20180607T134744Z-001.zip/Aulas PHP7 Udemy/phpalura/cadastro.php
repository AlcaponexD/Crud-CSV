<?php require_once ("header.php");?>
    <form action="adiciona-produto.php">
        <table class="table">
            <tr>
                <td>Nome</td>
                <td><input type="text" name="produto_nome" class="form-control" required /></td>
            </tr>

            <tr>
                <td>Preço</td>
                <td><input type="number" name="produto_valor" class="form-control" required /></td>
            </tr>

            <tr>
                <td><input type="submit" value="Cadastrar"  class="btn btn-primary" required/></td>
            </tr>

        </table>

    </form>
<?php require_once ("footer.php");?>