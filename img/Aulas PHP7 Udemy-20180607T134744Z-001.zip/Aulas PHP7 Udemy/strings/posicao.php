<?php

$nome = "Meu nome completo é jeison pedroso";
//strpos serve para mostra a posicção da palavra procurada na frase

$q = strpos($nome, "jeison");
var_dump ($q);
//Serve para mostrar o texto desde a posição de inicio(0) até a posição (17) a onde corresponde a variavel $q
$texto = substr($nome , 0 , $q);
var_dump ($texto);

echo "<br/>";

//Serve para mostrar o texto apos a variavel $q (sem incluir junto)
$texto2 = substr($nome, $q + strlen("Jeison"), strlen($nome));
var_dump ($texto2);
?>