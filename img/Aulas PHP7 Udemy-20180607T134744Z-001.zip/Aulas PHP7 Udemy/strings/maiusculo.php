<?php
$nome = "Jeison";
//Função strtoupper serve para deixar toda a palavra em MAIUSCULA

echo strtoupper($nome);
echo "<br/>";
//Funcao strtolower serve  para deixar  a palavra toda em minuscula

$nome_min = "Pedroso pedroso";
echo strtolower($nome_min);

echo "<br/>";
//Usada para deixar ssomente a primeira letra em maiusculo de todas as palavras
echo ucfirst($nome_min);
echo "<br/>";
//Serve para deixar a primeira letra de cada palavra em Maiuscula  (usada muito em nomes completos)
echo ucwords($nome_min);

?>