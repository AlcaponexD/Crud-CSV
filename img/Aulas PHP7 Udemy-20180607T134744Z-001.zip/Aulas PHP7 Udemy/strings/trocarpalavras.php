<?php
$nome = "Jeison";
//Troca letras  (Procura letra a ser trocada , Caractere a ser trocado , variavel)
echo str_replace("e" , "3", $nome);

?>