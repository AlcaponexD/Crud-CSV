<?php 
//Aspas duplas eu posso chamar uma variavel semprecisar concatenar 
$nome = "jeison";
$nome2 = 'jeison2';

echo "eu me chamo $nome e $nome2";
echo "</br>";
//Aspas simples eu preciso concatenar 
$nome = "jeison";
$nome2 = 'jeison2';

echo 'eu me chamo ' . $nome . ' e '  .$nome2;
 ?>