<?php

/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 27/04/2018
 * Time: 23:30
 */
class Civic extends Automovel
{

    public function empurrar()
    {
        echo "Lata véia";
    }
}
