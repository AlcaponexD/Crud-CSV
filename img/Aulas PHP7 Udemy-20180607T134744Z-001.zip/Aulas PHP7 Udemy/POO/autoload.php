<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 27/04/2018
 * Time: 23:29
 */

//Autoload serve para carregar as classes dependentes , ele procura na mesma pasta tudo relacionado a dependencia Civic
function __autoload($nomeClasse){
    require_once ("$nomeClasse.php");

}

$carro = new Civic();
$carro->acelerer(80);