<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 26/04/2018
 * Time: 19:34
 */


//Encapsulamentotambém se basea a esse codigo abaixo onde , só e possivel acessar um conteudo da classe se tiver um metodo publico de comunicação , nesse caso os setters e getters;

class Endereco {
    private $logradouro;
    private $numero;
    private $cidade;

    public function  __construct(){
        echo "testando";
    }

    public function getLogradouro()
    {
        return $this->logradouro;
    }

    public function setLogradouro($logradouro)
    {
        $this->logradouro = $logradouro;
    }


    public function getNumero()
    {
        return $this->numero;
    }

    public function setNumero($numero)
    {
        $this->numero = $numero;
    }


    public function getCidade()
    {
        return $this->cidade;
    }

    public function setCidade($cidade)
    {
        $this->cidade = $cidade;
    }

}

$adress = new Endereco();
$adress->setCidade("ibiúna");

var_dump($adress);