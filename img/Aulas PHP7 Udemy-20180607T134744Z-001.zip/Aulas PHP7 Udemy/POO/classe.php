<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 25/04/2018
 * Time: 19:33
 */
//Criei uma classe chamada pessoa
class Pessoa{
    //Adicionei uma variavel publica
    public $nome;
    //Adicinado uma funcao publica , porem para chamar a variavel de fora da função é preciso usar o $this->nome , ou seja nao precisa usar sifrao na variavel
    public function falar(){
        return "O meu nome é ".$this->nome;

    }
}
//Agora eu instanciei a classe em uma variavel chamada jeison
$jeison = new Pessoa();
//Depois de instanciada eu Acessei a variavel da classe instanciada e atribui um valor a ela
$jeison->nome = "Jeison Pedroso";
//Exibe a função falar que tem um retorn com string e carrega a variavel nome que foi passada no passo anterior.
echo $jeison->falar();