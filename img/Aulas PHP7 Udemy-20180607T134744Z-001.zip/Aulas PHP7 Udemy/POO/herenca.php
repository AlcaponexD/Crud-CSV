<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 26/04/2018
 * Time: 20:22
 */

//Caso tenham funcoues ou atributos com o mesmo nome , o lugar ocupado na memoria com esse nome é sómente 1 , então o ultima execução vai prevalecer , geralmente o filho
//Classe pai, também é basicamente polimorfismo
class SuperClasse{
    public $a ='Variavel é $a';

    public function ini() {
        echo "INIEQ";
    }
}
//Clase filho que herda tudo qeu o pai tem
class SubClasse extends SuperClasse {

}

$sub = new  SubClasse();
$sub->ini();
var_dump($sub);