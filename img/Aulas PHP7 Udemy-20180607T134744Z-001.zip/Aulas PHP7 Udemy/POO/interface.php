<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 26/04/2018
 * Time: 20:57
 */
//Interface serve para obrigar o codigo a seguir o seguntes passos que foram definidos , aqui no caso o codigo só funciona se tiver uma funcao publica acelerer , frenar , trocar marcha
interface Veiculos
{
    public function acelerer($velocidade);

    public function frenar($velocidade);

    public function TrocarMarcha($marcha);
}
//Implements é para puxar a interface obrigatoria no seu codigo
class Civic implements Veiculos {

    public function acelerer($velocidade)
    {
       echo "O veiculo acelerou até : ".$velocidade."KM";
        echo "<br>";
    }

    public function frenar($velocidade)
    {
        echo "O Veiculo frenou até : ".$velocidade."KM";
        echo "<br>";
    }

    public function TrocarMarcha($marcha)
    {
        echo "O Veiculo trocou a marcha".$marcha;
        echo "<br>";
    }
}

$honda = new Civic();
$honda->acelerer(70);
$honda->frenar(20);
$honda->TrocarMarcha(2);