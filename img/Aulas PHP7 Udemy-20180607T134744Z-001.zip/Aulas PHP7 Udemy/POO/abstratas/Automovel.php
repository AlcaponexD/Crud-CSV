<?php

/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 27/04/2018
 * Time: 23:31
 */
interface Veiculos
{
    public function acelerer($velocidade);

    public function frenar($velocidade);

    public function TrocarMarcha($marcha);
}
/*a palavra abstract impede que a classe seja instanciada diretamente, para isso é preciso de outra classe sub para acessar
a classe automoveil , e dai instancia a classe civic que ela vai instanciar e puxar a automovel.
*/
abstract class Automovel implements Veiculos {

    public function acelerer($velocidade)
    {
        echo "O veiculo acelerou até : ".$velocidade."KM";
        echo "<br>";
    }

    public function frenar($velocidade)
    {
        echo "O Veiculo frenou até : ".$velocidade."KM";
        echo "<br>";
    }

    public function TrocarMarcha($marcha)
    {
        echo "O Veiculo trocou a marcha".$marcha;
        echo "<br>";
    }
}