<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 27/04/2018
 * Time: 23:48
 */
//Função para pesquisar classes na pasta local
function incluirClasses($nomeClasses){
    Se caso a pasta existir puxar o nome da classe.php ,
    if (file_exists($nomeClasses.".php") === true){
        //se for o arquivo existir puxa uma só vez
        require_once ($nomeClasses.".php");
    }
}//puxa a função para puxa arquivo local
spl_autoload_register("incluirClasses");
//puxa arquivo de classe dentro de uma pasta especifica  (nome da pasta = abstratas)
spl_autoload_register(function ($nomeClasses){
if (file_exists("abstratas".DIRECTORY_SEPARATOR . $nomeClasses.".php") === true){
    require_once("abstratas".DIRECTORY_SEPARATOR . $nomeClasses.".php");
}
});
//instanciado a classe civic
$carro = new Civic();
//adicionado parametro de velocidade 90;
$carro->acelerer(90);