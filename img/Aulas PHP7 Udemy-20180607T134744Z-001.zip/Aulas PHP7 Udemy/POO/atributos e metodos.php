<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 25/04/2018
 * Time: 20:17
 */
//Classe criada
class Usuario{
    //Atributo privado criado
    private $login;
    //atributo privado criado
    private $senha;
    //recupera um valor e joga para o atributo login que estava em privado
    public function getLogin(){
        return $this->login;
    }
    //seta o valor do atributo login na variavel login
    public function setLogin($login){
        $this->login = $login;
    }
    public  function getSenha(){
        return$this->senha;
    }
    public  function setSenha($senha){
        $this->senha = $senha;
    }
    //Funcao para exibir os dados
    public function exibir(){
        return array(
            //Recupera o valor dos atributos
          "login"=>$this->getLogin(),
          "senha"=>$this->getSenha(),
        );
    }

}
//Instanciado a classe usuario
$acesso = new usuario();
//Adiciona valor ao atributo login
$acesso->setLogin("AlcaponexD");
//adiciona valor ao atributo senha
$acesso->setSenha("jeison");
//Exibe o objeto acesso com os dados da função com array exibir
print_r($acesso->exibir());

