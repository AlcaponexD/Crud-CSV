<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 23/04/2018
 * Time: 20:03
 */
//Exibe a data em formato de dia,mes,ano
echo date("d m Y");
//Converte a data colocada para timestamp que converte em segundos desde 01/01/1970 até a data passada na variavel,
$st = strtotime("2000-09-11");

echo "<br>";
//Exibe data no formato de dia da semana , dia/mes/ano e passa o valor do timestamp da variavel $st que faz a data virar a que foi passada na variavel (2000-98-11)
echo date("l, d m Y", $st);
echo '<br>';
//serve para definir  a localizacao para utilizacao de hora pt-br
setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'portuguese');
//exibe as primeiras letras em maiuscculas e puxa a data jaá formatada em portugues
echo ucwords(strftime('%A, %d, %B'));