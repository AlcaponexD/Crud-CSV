<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 21/04/2018
 * Time: 17:02
 */
//Função teste vai receber os parametros da variavel $valores e converter e obrigad todos a serem do tipo inteiros e depois da conversao vai mandar para tipo string com os :

//os ... servem para pegar todos os valores no parametro em forma de array(list)
function teste(int ...$valores):string {
    //Retorna os valor de parametros em forma de array , por isso o array_sum
    return array_sum($valores);

}

echo teste(4,3);