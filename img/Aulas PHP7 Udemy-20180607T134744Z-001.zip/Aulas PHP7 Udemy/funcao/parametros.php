<?php 
//Funcao criada teste que soma a+b e recebe o valor dos parametros passados quando é puxado a função em R = teste(1,5) onde a=1 e b= 5
function teste($a,$b){
    return($a+$b);
    }

$r = teste(1,5);

echo "A soma é igual $r";


?>
