<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 21/04/2018
 * Time: 17:02
 */
//Função teste vai receber os parametros da variavel $valores e converter e obrigad todos a serem do tipo inteiros
function teste(int ...$valores){
    //Retorna os valor de parametros em forma de array , por isso o array_sum
    return array_sum($valores);

}

echo teste(4,3);