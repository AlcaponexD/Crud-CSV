<?php
/**
 * Created by PhpStorm.
 * User: AlcaponexD
 * Date: 23/04/2018
 * Time: 20:00
 */
//Criei uma função que nao recebe nome , porem pode ser atribuido a uma variavel para chamar posteriormente.

$var = function ($texto){
    return $texto;
};

echo $var("Olá Mundo");