<?php

function teste (){
    return 942.00;

}
//Calculo da funçao teste que retorna o valor 942 multiplicado por 3;
echo "josé recebeu = " .   (teste()*3);
?>
