<?php 
	setcookie('nome', 'jeison');
	//cookie valido por 24 horas
	setcookie('cor', 'blue', time()+3600*24);


	echo "Hello" . $_COOKIE['nome'];




 ?>
	<!DOCTYPE html>
	<html>
	<head>
		<title></title>
	</head>
	<body bgcolor=" <?= $_cookie['cor']; ?> ">
		 
	</body>
	</html>

