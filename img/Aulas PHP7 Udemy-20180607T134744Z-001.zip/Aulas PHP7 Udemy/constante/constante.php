<?php
//CONSTANTE SEMPRE COMEÇA COM DEFINE , NOME + VALOR
define('SERVIDOR', '127.0.0.1' );
//Não precisa puxar a tag sifrao $  para usar a constante
echo SERVIDOR ; 
echo '<br>';

//pode ser usado a constante para pegar dados de uma variavel
define('CONEXAO_BANCO', [
    '127.0.01',
    'Usuario do banco',
    'Senha do banco',
    'Nome do banco de dados' 
]);
print_r (CONEXAO_BANCO);    
echo '<br>';
//EXIBE A VERSAO DO PHP
echo PHP_VERSION;
echo '<br>';
//EXIBE A BARRA DE DIRETORIO SE É \ OU / , para pesquisar mais joga no google    PHP Constantes reservadas
echo DIRECTORY_SEPARATOR;

?>