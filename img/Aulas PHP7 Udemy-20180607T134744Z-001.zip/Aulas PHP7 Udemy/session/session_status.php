<?php
//INICIA A SESSAO
session_start();
//EXIBE STATUS DA SESSAO
var_dump(session_status());
//EXIBE A RESPECTIVA MENSAGEM DA SESSAO QUE ESTIVER ATIVA;
switch (session_status()) {
    case PHP_SESSION_DISABLED:
        echo 'sessão do php esta inativa';
        break;

    case PHP_SESSION_NONE:
        echo 'sessão do php existe , mas nao esta ativa';
        break;

     case PHP_SESSION_ACTIVE:
        echo 'sessão do php existe e está ativa';

}

?>