<?php
//Starta uma sessao
session_start();
//Cria uma variavel de sessao com nome jeison e atribui o valor jeison
$_SESSION["nome"] = "Jeison";  

?>
