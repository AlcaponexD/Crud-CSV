<?php

session_start();
//Sempre que acessar a pagina ele vai gerar um novo ID é boa pratica para por isso numa tela de login para ninguem pegar os IDs 
//é como se fosse um ID temporario  , caso precise recuperar  uma sessao com id especifico é jogar antes do start session_id('numerodoid');
session_regenerate_id();

echo session_id();

?>