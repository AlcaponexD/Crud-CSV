<?php

session_start();

//unsset limpa  a sessao atual - caso acolocar sem nome de variavel apaga todas as sessoes 
//session_destroy serve para destruir a sessao toda
session_unset($_SESSION["nome"]);
echo $_SESSION["nome"];

?>