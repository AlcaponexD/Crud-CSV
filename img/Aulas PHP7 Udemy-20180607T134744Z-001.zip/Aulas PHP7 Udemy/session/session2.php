<?php
//starta uma sessao
session_start();
//exibe a sessao nome que está ativa apos iniciar o arquivo session.php que ativou uma sessao com nome jeison
echo $_SESSION["nome"];

?>